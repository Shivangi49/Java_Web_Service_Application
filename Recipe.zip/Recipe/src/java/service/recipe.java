/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.sql.*;
import java.util.*;
/**
 *
 * @author shiva
 */
@WebService(serviceName = "recipe")
public class recipe {

    /**
     * This is a sample web service operation
     */
     @WebMethod(operationName = "insertRecipe")
    public void insertRecipe(@WebParam(name = "id") int id, @WebParam(name = "name") String name,@WebParam(name = "description") String description) {
        //TODO write your implementation code here:
        try{
             Class.forName ("com.mysql.jdbc.Driver"); 
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bonappetit","root","");
            PreparedStatement ps=c.prepareStatement("insert into recipe values(?,?,?)");
            ps.setInt(1,id);
            ps.setString(2,name);
            ps.setString(3,description);
            ps.executeUpdate();
            c.commit();
        }
        catch(Exception e){}
      
    }
    
    @WebMethod(operationName = "getRecipe")
    public List getRecipe(@WebParam(name = "id") int id) {
        //TODO write your implementation code here:
        List l = new ArrayList();
        try{
             Class.forName ("com.mysql.jdbc.Driver"); 
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bonappetit","root","");
            PreparedStatement ps=c.prepareStatement("select * from recipe where id=?");
            ps.setInt(1,id);
            ResultSet rs=ps.executeQuery();
            
            if (rs.next())
            {
               l.add( "Name: "+rs.getString(2)+"   ,     Description:  " + rs.getString(3));
                return l;
            }
            else
                l.add("enter valid id...!!!");
                return l;
           
        }catch(Exception e)
        {
         l.add(e.toString());
         return l;
        }
       
    }
    @WebMethod(operationName = "deleteRecipe")
    public void deleteData(@WebParam(name = "id") int id) {
        try{
             Class.forName ("com.mysql.jdbc.Driver"); 
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bonappetit","root","");
            PreparedStatement ps=c.prepareStatement("delete from recipe where id=?");
            ps.setInt(1,id);
            ps.executeUpdate();
            c.commit();
        }
        catch(Exception e){}
    }
    
    @WebMethod(operationName = "updateRecipe")
    public void updateRecipe(@WebParam(name = "id") int id, @WebParam(name = "name") String name,@WebParam(name = "description") String description) {
        //TODO write your implementation code here:
        try{
             Class.forName ("com.mysql.jdbc.Driver"); 
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bonappetit","root","");
            PreparedStatement ps=c.prepareStatement("update recipe set name=?, description=? where id=?");
            ps.setString(1,name);
            ps.setString(2,description);
            ps.setInt(3,id);
            ps.executeUpdate();
            c.commit();
        }
        catch(Exception e){}
       
    }
}
