/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author shiva
 */
@WebService(serviceName = "restaurant")
public class restaurant {

    /**
     * This is a sample web service operation
     */
     @WebMethod(operationName = "insertData")
    public void insertData(@WebParam(name = "id") int id, @WebParam(name = "name") String name,@WebParam(name = "address") String address,@WebParam(name = "contact")  String contact) {
        //TODO write your implementation code here:
        try{
             Class.forName ("com.mysql.jdbc.Driver"); 
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bonappetit","root","");
            PreparedStatement ps=c.prepareStatement("insert into restaurant values(?,?,?,?)");
            ps.setInt(1,id);
            ps.setString(2,name);
            ps.setString(3,address);
            ps.setString(4,contact);
            ps.executeUpdate();
            c.commit();
        }
        catch(Exception e){
           
        }
    }

    @WebMethod(operationName = "getData")
    public List getData(@WebParam(name = "id") int id) {
        //TODO write your implementation code here:
        List l = new ArrayList();
        try{
             Class.forName ("com.mysql.jdbc.Driver"); 
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bonappetit","root","");
            PreparedStatement ps=c.prepareStatement("select * from restaurant where id=?");
            ps.setInt(1,id);
            ResultSet rs=ps.executeQuery();
            
            if (rs.next())
            {
               l.add( "Name: "+rs.getString(2)+"  ,   Address:  " + rs.getString(3)+ "  ,   Contact: " +rs.getString(4));
                return l;
            }
            else
                l.add("enter valid id...!!!");
                return l;
           
        }catch(Exception e)
        {
         l.add(e.toString());
         return l;
        }
       
    }
        
    
    @WebMethod(operationName = "deleteData")
    public void deleteData(@WebParam(name = "id") int id) {
        try{
             Class.forName ("com.mysql.jdbc.Driver"); 
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bonappetit","root","");
            PreparedStatement ps=c.prepareStatement("delete from restaurant where id=?");
            ps.setInt(1,id);
            ps.executeUpdate();
            c.commit();
        }
        catch(Exception e){}
    }
    
    @WebMethod(operationName = "updateData")
    public void updateData(@WebParam(name = "id") int id, @WebParam(name = "name") String name,@WebParam(name = "address") String address,@WebParam(name = "contact")  String contact) {
        //TODO write your implementation code here:
        try{
             Class.forName ("com.mysql.jdbc.Driver"); 
            Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bonappetit","root","");
            PreparedStatement ps=c.prepareStatement("update restaurant set name=?, address=?,contact=? where id=?");
            ps.setString(1,name);
            ps.setString(2,address);
            ps.setString(3,contact);
            ps.setInt(4,id);
            ps.executeUpdate();
            c.commit();
        }
        catch(Exception e){}
       
    }
}
